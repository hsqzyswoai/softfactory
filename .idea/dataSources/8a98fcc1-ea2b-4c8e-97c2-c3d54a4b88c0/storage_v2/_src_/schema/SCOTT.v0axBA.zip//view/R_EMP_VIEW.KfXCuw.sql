CREATE VIEW R_EMP_VIEW AS
  select empno,ename,job,sal,deptno from emp with read only
/

