CREATE VIEW DP10_30_VIEW AS
  select e.deptno 部门编号,e.empno,e.ename,e.job,e.sal,d.dname,d.loc from emp e,dept d where e.deptno in(10,30)and e.deptno=d.deptno order by e.deptno
/

