CREATE VIEW C_EMP_VIEW AS
  select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp with check option
/

