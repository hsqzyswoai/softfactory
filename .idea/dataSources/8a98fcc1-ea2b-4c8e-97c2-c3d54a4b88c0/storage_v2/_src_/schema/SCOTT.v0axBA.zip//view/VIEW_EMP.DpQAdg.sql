CREATE VIEW VIEW_EMP AS
  select empno,ename,sal,d.deptno,d.loc from emp n,scott.dept d where n.deptno=d.deptno
/

